package edu.westga.cs1302.menureview.view.output;

import edu.westga.cs1302.menureview.model.MenuItem;
import edu.westga.cs1302.menureview.model.Restaurant;
import edu.westga.cs1302.menureview.model.RestaurantGroup;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

import edu.westga.cs1302.menureview.model.Menu;

/**
 * The Class ReportGenerator.
 * 
 * @author CS1302
 */
public class ReportGenerator {

	/**
	 * Builds the full summary report of the specified menu of a restaurant. If menu
	 * is null, instead of throwing an exception will return a string saying "No
	 * menu exists.", otherwise builds a summary report of the menu.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @param restaurant the restaurant
	 *
	 * @return A formatted summary string of the restaurant's menu.
	 */
	public String buildFullSummaryReport(Restaurant restaurant) {
		String summary = "";

		if (restaurant == null || restaurant.getMenu() == null) {
			summary = "No menu exists.";
		} else {
			Menu menu = restaurant.getMenu();
			summary = restaurant.getName() + System.lineSeparator();
			summary += "#Menu items: " + menu.size() + System.lineSeparator();

			if (menu.size() > 0) {
				MenuItem bestItem = menu.findBestMenuItem();
				MenuItem worstItem = menu.findWorstMenuItem();
				
				summary += System.lineSeparator();
	
				summary += "Highest rated item: ";
				summary += this.buildMenuItemOutput(bestItem) + System.lineSeparator();
				summary += "Lowest rated item: ";
				summary += this.buildMenuItemOutput(worstItem) + System.lineSeparator();
				
				summary += System.lineSeparator();
				summary += this.buildCountsByRating(restaurant);
			}
		}
		return summary;
	}

	private String buildMenuItemOutput(MenuItem menuItem) {
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(Locale.US);
		String output = menuItem.getName() + " " + menuItem.getCalories() + " "
				+ currencyFormatter.format(menuItem.getPrice()) + " " + menuItem.getRating();
		return output;
	}

	private String buildCountsByRating(Restaurant restaurant) {
		Menu menu = restaurant.getMenu();
		int[] count = menu.getNumberItemsByRating();
		String output = "";

		for (int i = 0; i < MenuItem.UPPER_BOUND_RATING - 1; i++) {
			String tallyMarks = this.getTallyMarks(count, i);
			output += "# items rated " + (i + 1) + "/" + (i + 2) + ": " + tallyMarks + System.lineSeparator();
			i++;
		}

		return output;
	}

	private String getTallyMarks(int[] count, int index) {
		int numOfRatings = (count[index] + count[index + 1]);
		String tallyMarks = "";
		for (int x = 0; x < numOfRatings; x++) {
			tallyMarks += "| ";
		}
		return tallyMarks;
	}
	
	/**
	 * Returns a list of menu items at a provided restaurant with the provided search term
	 * 
	 * @precondition searchTerm != null
	 * @postcondition none
	 * 
	 * @param searchTerm is the term to search the menu items for
	 * @param restaurant is the restaurant whose menu will be searched
	 * 
	 * @return a list of menu items matching the search term in string format
	 */
	public String getRestaurantMenuItemsContaining(String searchTerm, Restaurant restaurant) {
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(Locale.US);
		ArrayList<MenuItem> matchingItems = this.getMatchingMenuItems(searchTerm, restaurant);
		if (matchingItems.isEmpty()) {
			return "No items with " + searchTerm + " at " + restaurant.getName();
		} else {
			return "Menu items at " + restaurant.getName() + " containing " + searchTerm + ":" + System.lineSeparator() + this.menuItemsList(matchingItems) + System.lineSeparator()
					+  "Average price of matching menu items: " + currencyFormatter.format(this.calculateAveragePriceOfMatchingItems(matchingItems)) + System.lineSeparator();
			
		}
	}

	private ArrayList<MenuItem> getMatchingMenuItems(String searchTerm, Restaurant restaurant) {
		Menu restaurantMenu = restaurant.getMenu();
		ArrayList<MenuItem> matchingList = restaurantMenu.searchForItemsContaining(searchTerm);
		return matchingList;
	}
	
	private String menuItemsList(ArrayList<MenuItem> menuItems) {
		String menuItemsList = "";
		for (int i = 0; i < menuItems.size(); i++) {
			menuItemsList += menuItems.get(i).getName() + System.lineSeparator();
		}
		return menuItemsList;
	}
	
	private double calculateAveragePriceOfMatchingItems(ArrayList<MenuItem> menuItems) {
		double totalPrice = 0.0;
		for (int i = 0; i < menuItems.size(); i++) {
			totalPrice += menuItems.get(i).getPrice();
		}
		return totalPrice / menuItems.size();
	}
	
	/**
	 * Creates a string for all restaurants with menu items that contain a given search term in a given restaurant group
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @param searchTerm is the term to search the menu items for
	 * @param restaurantGroup is the group of restaurants whose menus will be searched
	 * 
	 * @return all menu items that match the search term provided broken down by restaurant in string format
	 */
	
	public String getMenuItemsFromRestaurantGroupContaining(String searchTerm, RestaurantGroup restaurantGroup) {
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(Locale.US);
		ArrayList<Restaurant> restaurants = restaurantGroup.getRestaurants();
		String finalString = "";
		double totalPrice = 0.0;
		ArrayList<Restaurant> matchingRestaurants = new ArrayList<Restaurant>();
		for (Restaurant restaurant : restaurants) {
			if (this.doesRestaurantMenuItemMatch(searchTerm, restaurantGroup)) {
				matchingRestaurants.add(restaurant);
			}
			totalPrice += this.getMatchingMenuItems(searchTerm, restaurant).get(0).getPrice();
			finalString += this.getRestaurantMenuItemsContaining(searchTerm, restaurant) + System.lineSeparator();
		}
		return finalString + "Average price for matching menu items from all restaurants: " 
							+ currencyFormatter.format(this.getTotalAveragePrice(totalPrice, matchingRestaurants));
	} 
	
	private boolean doesRestaurantMenuItemMatch(String searchTerm, RestaurantGroup restaurantGroup) {
		ArrayList<Restaurant> restaurants = restaurantGroup.getRestaurants();
		for (Restaurant restaurant : restaurants) {
			ArrayList<MenuItem> matchingMenuItems = this.getMatchingMenuItems(searchTerm, restaurant);
			if (matchingMenuItems.isEmpty()) {
				return false;
			}
		}
		return true;
	}
	
	private double getTotalAveragePrice(Double totalPrice, ArrayList<Restaurant> matchingRestaurants) {
		double numOfRestaurants = matchingRestaurants.size();
		double average = totalPrice / numOfRestaurants;
		return average;
	}
}