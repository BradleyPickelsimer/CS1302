package edu.westga.cs1302.menureview.model;

import edu.westga.cs1302.menureview.resources.UI;

/**
 * The Class Restaurant.
 * 
 * @author CS1302
 */
public class Restaurant {
	private String name;
	private Menu menu;
	
	/**
	 * Instantiates a new restaurant.
	 * 
	 * @precondition none
	 * @postcondition getName() == "Unknown" && getMenu().size() == 0
	 */
	public Restaurant() {
		this.name = "Unknown";
		this.menu = new Menu();
	}
	
	/**
	 * Instantiates a new restaurant.
	 * 
	 * @precondition name cannot be null or empty
	 * @postcondition getName() == name && getMenu().size() == 0
	 *
	 * @param name the restaurant name
	 */
	public Restaurant(String name) {
		if (name == null) {
			throw new IllegalArgumentException(UI.ExceptionMessages.RESTAURANT_NAME_CANNOT_BE_NULL);
		}

		if (name.isEmpty()) {
			throw new IllegalArgumentException(UI.ExceptionMessages.RESTAURANT_NAME_CANNOT_BE_EMPTY);
		}

		this.name = name;
		this.menu = new Menu();
	}

	/**
	 * Gets the restaurant name.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Sets the restaurant name.
	 * 
	 * @precondition name cannot be null or empty
	 * @postcondition getName() == name
	 *
	 * @param name the restaurant name to set
	 */
	public void setName(String name) {
		if (name == null) {
			throw new IllegalArgumentException(UI.ExceptionMessages.RESTAURANT_NAME_CANNOT_BE_NULL);
		}

		if (name.isEmpty()) {
			throw new IllegalArgumentException(UI.ExceptionMessages.RESTAURANT_NAME_CANNOT_BE_EMPTY);
		}

		this.name = name;
	}
	
	/**
	 * Gets the menu.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the menu
	 */
	public Menu getMenu() {
		return this.menu;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return this.name;
	}

}
