package edu.westga.cs1302.menureview.test.menu;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1302.menureview.model.Menu;
import edu.westga.cs1302.menureview.model.MenuItem;

class TestSearchForItemsContaining {

	@Test
	void searchWithNullTerm() {
		Menu menu = new Menu();
		menu.add(new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9));
		
		assertThrows(IllegalArgumentException.class, () -> {
			menu.searchForItemsContaining(null);
		});
	}
	
	@Test
	void searchWithValidTermEmptyList() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("butter");
		
		assertEquals(expectedList, actualList);
	}
	
	@Test
	void searchWithValidTermSingleEntryListNoMatch() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		menu.add(new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9));
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("flavor");
		
		assertEquals(expectedList, actualList);
	}
	
	@Test
	void searchWithValidTermSingleEntryListWithMatchSameCase() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		MenuItem fudge = new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9);
		menu.add(fudge);
		expectedList.add(fudge);
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("Butter");
		
		assertEquals(expectedList, actualList);
	}
	
	@Test
	void searchWithValidTermSingleEntryListWithMatchDifferentCase() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		MenuItem fudge = new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9);
		menu.add(fudge);
		expectedList.add(fudge);
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("butter");
		
		assertEquals(expectedList, actualList);
	}
	
	@Test
	void searchWithValidTermMultipleEntryListWithNoMatch() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		MenuItem fudge = new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9);
		MenuItem caramelPie = new MenuItem("Caramel Pie", "Caramel in a graham cracker crust", 3.49, 620, 5);
		MenuItem iceCream = new MenuItem("Ice Cream", "Creamy vanilla ice cream", 2.99, 250, 7);
		menu.add(fudge);
		menu.add(caramelPie);
		menu.add(iceCream);
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("flavor");
		
		assertEquals(expectedList, actualList);
	}
	
	@Test
	void searchWithValidTermMultipleEntryListWithOneMatch() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		MenuItem fudge = new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9);
		MenuItem caramelPie = new MenuItem("Caramel Pie", "Caramel in a graham cracker crust", 3.49, 620, 5);
		MenuItem iceCream = new MenuItem("Ice Cream", "Creamy vanilla ice cream", 2.99, 250, 7);
		menu.add(fudge);
		menu.add(caramelPie);
		menu.add(iceCream);
		expectedList.add(fudge);
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("butter");
		
		assertEquals(expectedList, actualList);
	}
	
	@Test
	void searchWithValidTermMultipleEntryListWithSomeMatches() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		MenuItem fudge = new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9);
		MenuItem caramelPie = new MenuItem("Caramel Pie", "Caramel in a graham cracker crust", 3.49, 620, 5);
		MenuItem iceCream = new MenuItem("Ice Cream", "Creamy fudge flavored ice cream", 2.99, 250, 7);
		menu.add(fudge);
		menu.add(caramelPie);
		menu.add(iceCream);
		expectedList.add(fudge);
		expectedList.add(iceCream);
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("fudge");
		
		assertEquals(expectedList, actualList);
	}
	
	@Test
	void searchWithValidTermMultipleEntryListWithAllMatches() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		MenuItem fudge = new MenuItem("Butter Pecan Fudge", "Rich and nutty flavored fudge", 3.99, 940, 9);
		MenuItem caramelPie = new MenuItem("Caramel Pie", "Caramel flavoring in a graham cracker crust", 3.49, 620, 5);
		MenuItem iceCream = new MenuItem("Ice Cream", "Creamy fudge flavored ice cream", 2.99, 250, 7);
		menu.add(fudge);
		menu.add(caramelPie);
		menu.add(iceCream);
		expectedList.add(fudge);
		expectedList.add(caramelPie);
		expectedList.add(iceCream);
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("flavor");
		
		assertEquals(expectedList, actualList);
	}
	
	@Test
	void searchWithEmptyTermMultipleEntryList() {
		Menu menu = new Menu();
		ArrayList<MenuItem> expectedList = new ArrayList<MenuItem>();
		MenuItem fudge = new MenuItem("Butter Pecan Fudge", "Rich and nutty flavored fudge", 3.99, 940, 9);
		MenuItem caramelPie = new MenuItem("Caramel Pie", "Caramel flavoring in a graham cracker crust", 3.49, 620, 5);
		MenuItem iceCream = new MenuItem("Ice Cream", "Creamy fudge flavored ice cream", 2.99, 250, 7);
		menu.add(fudge);
		menu.add(caramelPie);
		menu.add(iceCream);
		expectedList.add(fudge);
		expectedList.add(caramelPie);
		expectedList.add(iceCream);
		
		ArrayList<MenuItem> actualList = menu.searchForItemsContaining("");
		
		assertEquals(expectedList, actualList);
	}
}
