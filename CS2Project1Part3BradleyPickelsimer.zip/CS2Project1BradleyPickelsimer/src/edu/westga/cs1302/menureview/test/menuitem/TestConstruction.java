package edu.westga.cs1302.menureview.test.menuitem;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1302.menureview.model.MenuItem;

public class TestConstruction {
	private static final double DELTA = 0.000001;

	@Test
	public void testValidConstruction() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 10.99, 1240, 7);
		assertAll(() -> assertEquals("Chicken Tenders", menuItem.getName()),
				() -> assertEquals("Crispy breaded chicken tenders", menuItem.getDescription()),
				() -> assertEquals(10.99, menuItem.getPrice(), DELTA), () -> assertEquals(1240, menuItem.getCalories()),
				() -> assertEquals(7, menuItem.getRating()));
	}

	@Test
	public void testNullName() {
		IllegalArgumentException exc = assertThrows(IllegalArgumentException.class,
				() -> new MenuItem(null, "Crispy breaded chicken tenders", 10.99, 1240, 7));
		assertEquals("name cannot be null.", exc.getMessage());
	}

	@Test
	public void testEmptyName() {
		assertThrows(IllegalArgumentException.class, () -> new MenuItem("", "Crispy breaded chicken tenders", 10.99, 1240, 7));
	}

	@Test
	public void testNullDescription() {
		IllegalArgumentException exc = assertThrows(IllegalArgumentException.class, () -> new MenuItem("Chicken Tenders", null, 10.99, 1240, 7));
		assertEquals("description cannot be null.", exc.getMessage());
	}
	
	@Test
	public void testEmptyDescription() {
		assertThrows(IllegalArgumentException.class, () -> new MenuItem("Chicken Tenders", "", 10.99, 1240, 7));
	}
	
	@Test
	public void testPriceJustBelowLowerBound() {
		assertThrows(IllegalArgumentException.class,
				() -> new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", -0.01, 1240, 7));
	}

	@Test
	public void testPriceAtLowerBound() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 0, 1240, 7);
		assertEquals(0, menuItem.getPrice(), DELTA);
	}

	@Test
	public void testPriceJustAboveLowerBound() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 0.01, 1240, 7);
		assertEquals(0.01, menuItem.getPrice(), DELTA);
	}

	@Test
	public void testCaloriesJustBelowLowerBound() {
		assertThrows(IllegalArgumentException.class,
				() -> new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 10.99, -1, 7));
	}

	@Test
	public void testCaloriesAtLowerBound() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 10.99, 0, 7);
		assertEquals(0, menuItem.getCalories());
	}

	@Test
	public void testCaloriesJustAboveLowerBound() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 10.99, 1, 7);
		assertEquals(1, menuItem.getCalories());
	}

	@Test
	public void testRatingJustBelowLowerBound() {
		assertThrows(IllegalArgumentException.class,
				() -> new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 10.99, 1240, 0));
	}

	@Test
	public void testRatingAtLowerBound() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 10.99, 1240, 1);
		assertEquals(1, menuItem.getRating());
	}

	@Test
	public void testRatingJustAboveLowerBound() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 0.01, 1240, 2);
		assertEquals(2, menuItem.getRating());
	}

	@Test
	public void testRatingJustAboveUpperBound() {
		assertThrows(IllegalArgumentException.class,
				() -> new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 10.99, 1240, 11));
	}

	@Test
	public void testRatingAtUpperBound() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 10.99, 1240, 10);
		assertEquals(10, menuItem.getRating());
	}

	@Test
	public void testRatingJustBelowUpperBound() {
		MenuItem menuItem = new MenuItem("Chicken Tenders", "Crispy breaded chicken tenders", 0.01, 1240, 9);
		assertEquals(9, menuItem.getRating());
	}
}
