package edu.westga.cs1302.menureview.test.menu;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1302.menureview.model.Menu;
import edu.westga.cs1302.menureview.model.MenuItem;

public class TestAdd {

	@Test
	public void testAddNullMenuItem() {
		Menu menu = new Menu();
		assertThrows(IllegalArgumentException.class, () -> menu.add(null));
	}
	
	@Test
	public void testAddMenuItemToEmptyMenu() {
		Menu menu = new Menu();
		menu.add(new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9));
		assertEquals(1, menu.size());
	}
	
	@Test
	public void testAddMultiplesMenuItemsToMenu() {
		Menu menu = new Menu();
		menu.add(new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9));
		menu.add(new MenuItem("Caramel Pie", "Caramel in a graham cracker crust", 3.49, 620, 5));
		assertEquals(2, menu.size());
	}
	
	@Test
	public void testAddDuplicateMenuItemsToMenuCaseSame() {
		Menu menu = new Menu();
		menu.add(new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9));
	
		assertThrows(IllegalArgumentException.class, () -> {
			menu.add(new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9));
		});
	}

	@Test
	public void testAddDuplicateMenuItemsToMenuCaseDifferent() {
		Menu menu = new Menu();
		menu.add(new MenuItem("Butter Pecan Fudge", "Rich and nutty fudge", 3.99, 940, 9));
	
		assertThrows(IllegalArgumentException.class, () -> {
			menu.add(new MenuItem("butter pecan fudge", "Rich and nutty fudge", 3.99, 940, 9));
		});
	}
}
