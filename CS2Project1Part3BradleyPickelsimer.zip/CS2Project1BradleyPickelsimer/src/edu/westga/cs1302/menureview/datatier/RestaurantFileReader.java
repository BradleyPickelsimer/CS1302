package edu.westga.cs1302.menureview.datatier;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import edu.westga.cs1302.menureview.model.MenuItem;
import edu.westga.cs1302.menureview.model.Restaurant;
import edu.westga.cs1302.menureview.model.RestaurantGroup;
import edu.westga.cs1302.menureview.resources.UI;

/**
 * The Class RestaurantFileReader. 
 * 
 * Reads an .rmd (Restaurant Menu Data) File which is a CSV file with the following format:
 * name,description,calories,price,rating
 * 
 * @author CS1302
 */
public class RestaurantFileReader {
	public static final String FIELD_SEPARATOR = ",";

	private File restaurantFile;
	private File readErrors = new File("readErrors.log");

	/**
	 * Instantiates a new restaurant file reader.
	 *
	 * @precondition restaurantFile != null
	 * @postcondition none
	 * 
	 * @param restaurantFile
	 *            the restaurant menu data file
	 */
	public RestaurantFileReader(File restaurantFile) {
		if (restaurantFile == null) {
			throw new IllegalArgumentException(UI.ExceptionMessages.RESTAURANT_FILE_CANNOT_BE_NULL);
		}
		
		this.restaurantFile = restaurantFile;
	}

	/**
	 * Opens the associated rmd file and reads all the menu items in the file one
	 * line at a time. Parses each line and creates a menu item object and stores it in
	 * an ArrayList of menu item objects. Once the file has been completely read the
	 * ArrayList of menu items is returned from the method. Assumes all
	 * menu items in the file are for the same restaurant.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return Collection of menu item objects read from the file.
	 * @throws FileNotFoundException the file not found exception
	 */
	public ArrayList<MenuItem> loadAllMenuItems() throws FileNotFoundException {
		ArrayList<MenuItem> menuItems = new ArrayList<MenuItem>();

		try (Scanner input = new Scanner(this.restaurantFile)) {
			while (input.hasNextLine()) {
				String line = input.nextLine();
				String[] fields = this.splitLine(line, RestaurantFileReader.FIELD_SEPARATOR);
				
				try {
					MenuItem menuItem = this.makeMenuItem(fields);
					menuItems.add(menuItem);
				} catch (ArrayIndexOutOfBoundsException | IllegalArgumentException exc) {
					this.printErrorToLogFile(this.readErrors, exc, line);
				}
			}
		}

		return menuItems;  
	}
	
	private MenuItem makeMenuItem(String[] fields) {
		String name = fields[0];
		String description = fields[1];
		int calories = Integer.parseInt(fields[2]);
		double price = Double.parseDouble(fields[3]);
		int rating = Integer.parseInt(fields[4]);
		return new MenuItem(name, description, price, calories, rating);
	}

	private String[] splitLine(String line, String fieldSeparator) {
		return line.split(fieldSeparator);
	}

	/**
	 * Loads all menu items in a file into a restaurant group, placing the items  into the appropriate restaurant's menu.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @param restaurantGroup is the restaurant group containing the restaurants in which the menu items will be added.
	 * 
	 * @return Collection of restaurant objects with menus read from the file
	 * 
	 * @throws FileNotFoundException 
	 */
	
	public ArrayList<Restaurant> loadMenuItemsToGroup(RestaurantGroup restaurantGroup) throws FileNotFoundException {
		ArrayList<Restaurant> restaurants = restaurantGroup.getRestaurants();
		
		try (Scanner scan = new Scanner(this.restaurantFile)) {
			while (scan.hasNextLine()) {
				String line = scan.nextLine();
				String[] fields = this.splitLine(line, RestaurantFileReader.FIELD_SEPARATOR);
				if (this.isRestaurantInGroup(fields[0], restaurantGroup)) {
					try {
						for (Restaurant restaurant : restaurants) {
							if (fields[0].equalsIgnoreCase(restaurant.getName())) {
								restaurant.getMenu().add(this.createMenuItem(fields));
							}
						}
					} catch (ArrayIndexOutOfBoundsException | IllegalArgumentException exc) {
						this.printErrorToLogFile(this.readErrors, exc, line);
					}
				} else { 
					try {
						Restaurant newRestaurant = new Restaurant(fields[0]);
						restaurants.add(newRestaurant);
						newRestaurant.getMenu().add(this.createMenuItem(fields));
					} catch (ArrayIndexOutOfBoundsException | IllegalArgumentException exc) {
						this.printErrorToLogFile(this.readErrors, exc, line);
					}
				}
			}
		}
		return restaurants;
	}
	
	private boolean isRestaurantInGroup(String restaurantName, RestaurantGroup restaurantGroup) {
		ArrayList<Restaurant> restaurants = restaurantGroup.getRestaurants();
		for (Restaurant restaurant : restaurants) {
			if (restaurantName.equalsIgnoreCase(restaurant.getName())) {
				return true;
			}
		}
		return false;
	}
	
	private MenuItem createMenuItem(String[] fields) {
		String name = fields[1];
		String description = fields[2];
		int calories = Integer.parseInt(fields[3]);
		double price = Double.parseDouble(fields[4]);
		int rating = Integer.parseInt(fields[5]);
		return new MenuItem(name, description, price, calories, rating);
	}
	
	private void printErrorToLogFile(File file, Exception exc, String line) {
		try (FileWriter writer = new FileWriter(file, true)) {
			if (!file.exists()) {
				file.createNewFile();
			} else {
				writer.write("Error reading file: " + exc.getMessage() + ": " + line + "\n");
			}
		} catch (IOException excep) {
			System.err.println("Could not log error.");
		}
	}
}
