package edu.westga.cs1302.menureview.datatier;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

import edu.westga.cs1302.menureview.model.MenuItem;
import edu.westga.cs1302.menureview.resources.UI;

/**
 * The Class RestaurantFileWriter.
 * 
 * @author CS1302
 */
public class RestaurantFileWriter {

	private File restaurantFile;

	/**
	 * Instantiates a new restaurant file writer.
	 *
	 * @precondition restaurantFile != null
	 * @postcondition none
	 * 
	 * @param restaurantFile the restaurant file
	 */
	public RestaurantFileWriter(File restaurantFile) {
		if (restaurantFile == null) {
			throw new IllegalArgumentException(UI.ExceptionMessages.RESTAURANT_FILE_CANNOT_BE_NULL);
		}

		this.restaurantFile = restaurantFile;
	}

	/**
	 * Writes all the menu items of the restaurant to the specified restaurant menu file. Each menu item
	 * will be on a separate line and of the following format:
	 * name,description,calories,price,rating
	 * 
	 * @precondition menu items != null
	 * @postcondition none
	 * 
	 * @param menuItems the collection of menu items to write to file.
	 * @throws FileNotFoundException the file not found exception
	 */
	public void write(ArrayList<MenuItem> menuItems) throws FileNotFoundException {
		if (menuItems == null) {
			throw new IllegalArgumentException(UI.ExceptionMessages.MENUITEMS_CANNOT_BE_NULL);
		}

		try (PrintWriter writer = new PrintWriter(this.restaurantFile)) {
			for (MenuItem currItem : menuItems) {
				String output = currItem.getName() + RestaurantFileReader.FIELD_SEPARATOR;
				output += currItem.getDescription() + RestaurantFileReader.FIELD_SEPARATOR;
				output += currItem.getCalories() + RestaurantFileReader.FIELD_SEPARATOR;
				output += currItem.getPrice() + RestaurantFileReader.FIELD_SEPARATOR;
				output += currItem.getRating();
				
				writer.println(output);
			}
		}

	}

}
